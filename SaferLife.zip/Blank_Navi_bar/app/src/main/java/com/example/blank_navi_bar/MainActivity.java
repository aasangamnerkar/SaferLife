package com.example.blank_navi_bar;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Log;
import android.view.ContextThemeWrapper;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.zxing.Result;
import com.google.zxing.WriterException;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import org.w3c.dom.Text;

import java.lang.reflect.Array;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;

import androidmads.library.qrgenearator.QRGContents;
import androidmads.library.qrgenearator.QRGEncoder;
import me.dm7.barcodescanner.zxing.ZXingScannerView;

public class MainActivity extends AppCompatActivity {
    public static ArrayList<Account> Accounts;

    public static ArrayList<location> Locations = new ArrayList<location>();

    private static int current_index;
    public static Button scan_btn;
    public static ImageView qrImage;
    public static Date date_infected;
    public static boolean isLocation;

    public static ArrayList<location> getLocations()
    {
        return Locations;
    }

    public static boolean isLocation()
    {
        return isLocation;
    }

    public static int getIndex()
    {
        return current_index;
    }

    public void clear(View v)
    {
        System.out.println("ya clicked nothing");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        BottomNavigationView navView = findViewById(R.id.nav_view);
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.navigation_home, R.id.navigation_dashboard, R.id.navigation_notifications)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        NavigationUI.setupWithNavController(navView, navController);


        ArrayList<Account> a_list = new ArrayList<Account>();

        Account a1 = new Account("1234567890", "1234", "user1");
        Account a2 = new Account("0123456789", "0123", "user2");
        Account a3 = new Account("2242399933", "password", "user3");
        Account a4 = new Account("0", "pw", "user4");
        Account a5 = new Account("1111111111", "password", "Arnav");
        Account a6 = new Account("3", "password", "Arnav2");
        Account a7= new Account("2", "password", "Arnav3");

        a1.setRisk(true);
        a2.setInfected(true);

        person_met p1 = new person_met(a1);
        person_met p2 = new person_met(a2);
        person_met p3 = new person_met(a3);

        a5.people_met.add(p1);
        a5.people_met.add(p2);
        a5.people_met.add(p3);

        a_list.add(a1);
        a_list.add(a2);
        a_list.add(a3);
        a_list.add(a4);
        a_list.add(a5);

        this.Accounts = a_list;

        location l1 = new location("Fremd High School", "password");
        l1.people_here.add(new person_met(a6));
        l1.people_here.add(new person_met(a7));
        Locations.add(l1);


        current_index = -1;
    }

    public void loadQR(View v)
    {
        if (current_index != -1)
        {
            qrImage = (ImageView) findViewById(R.id.qrView);
            String inputValue;

            if (!isLocation)
            {
                inputValue = Accounts.get(current_index).getNumber();
            }
            else
            {
                inputValue = "name" + Locations.get(current_index).name;
            }

            QRGEncoder qrgEncoder = new QRGEncoder(inputValue, null, QRGContents.Type.TEXT, 500);

            try
            {
                Bitmap bitmap = qrgEncoder.encodeAsBitmap();
                qrImage.setImageBitmap(bitmap);
            }
            catch (WriterException e)
            {
                Toast.makeText(getApplicationContext(), "FETUS DELETUS", Toast.LENGTH_SHORT).show();
            }
        }
        else
        {
            Toast.makeText(getApplicationContext(), "YOU ARE NOT LOGGED IN", Toast.LENGTH_SHORT).show();
        }
    }

    public static ArrayList<Account> getAccounts()
    {
        return Accounts;
    }

    public void startQRScanner(View v) {
        if (current_index != -1)
        {
            if (!isLocation)
            {
                Intent scanner = new Intent(getApplicationContext(), ScanCodeActivity.class);
                startActivity(scanner);
            }
            else
            {
                Toast.makeText(getApplicationContext(), "A LOCATION CANNOT ADD PEOPLE. IN ORDER TO ADD THIS ACCOUNT, SCAN ITS QR CODE.", Toast.LENGTH_SHORT).show();
            }
        }
        else
        {
            Toast.makeText(getApplicationContext(), "YOU ARE NOT LOGGED IN", Toast.LENGTH_SHORT).show();
        }
    }

    public void load_dashboard(View v)
    {
        ArrayAdapter<String> infectedArrayAdapter;
        ArrayAdapter<String> metArrayAdapter;

        ListView infected_view = (ListView) findViewById(R.id.infectedView);
        ListView met_view = (ListView) findViewById(R.id.infectedView);
        ArrayList<person_met> unfiltered;

        if (!isLocation)
        {
            unfiltered = Accounts.get(current_index).people_met;
        }
        else
        {
            unfiltered = Locations.get(current_index).people_here;
        }

        ArrayList<String> infected = new ArrayList<String>();
        ArrayList<String> risk = new ArrayList<String>();
        ArrayList<String> met = new ArrayList<String>();


        for (int i = 0; i < unfiltered.size();i++)
        {
            person_met p = unfiltered.get(i);
            Date current_date = new Date();
            System.out.println(p.person.getName());
            if (p.date.compareTo(current_date) < 14)
            {
                Account a = p.person;
                if (a.getInfected() == false)
                {
                    if (a.getRisk() == true)
                    {
                        risk.add(a.getName() + "      at risk    Date Met: " + unfiltered.get(i).time);
                    } else {
                        met.add(a.getName() + "      safe       Date Met: " + unfiltered.get(i).time);
                        Accounts.get(current_index).setRisk(true);
                    }
                }
                else if (a.getInfected() == true)
                {
                    infected.add(a.getName() + "       infected      Date Met: " + unfiltered.get(i).time);
                    ArrayList<person_met> account_infected = a.people_met;
                    for (int index = 0; i < account_infected.size(); index++)
                    {
                        Account acc = account_infected.get(index).person;
                        acc.setRisk(true);
                    }
                }
            }
        }

            for (String s : risk) {
                infected.add(s);
            }

            for (String s : met) {
                infected.add(s);
            }

            infectedArrayAdapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, infected);
            infected_view.setAdapter(infectedArrayAdapter);

            infectedArrayAdapter.notifyDataSetChanged();

    }

    public void login(View v)
    {
        EditText phone_number_login = (EditText) findViewById(R.id.number_input);
        EditText name_login = (EditText) findViewById(R.id.name_input);
        EditText password_login = (EditText) findViewById(R.id.password_input);
        CheckBox checkBoxLocation = (CheckBox) findViewById(R.id.checkedTextView);

        String number_input = phone_number_login.getText().toString();
        String password_input = password_login.getText().toString();
        String name_input = name_login.getText().toString();
        isLocation = checkBoxLocation.isChecked();

        boolean isFound = false;

        if (current_index != -1)
        {
            Toast.makeText(getApplicationContext(), "YOU ARE ALREADY LOGGED IN", Toast.LENGTH_SHORT).show();
        }
        else
        {
            if (!isLocation)
            {
                for (int i = 0; i < Accounts.size(); i++)
                {
                    Account a = Accounts.get(i);
                    if (number_input.equals(a.getNumber()))
                    {
                        isFound = true;
                        if (password_input.equals(a.getPw()))
                        {
                            System.out.println("SUCCESS");
                            this.current_index = i;


                            TextView phone_text = (TextView) findViewById(R.id.EnterPhone);
                            EditText phone_input = (EditText) findViewById(R.id.number_input);
                            TextView name_text = (TextView) findViewById(R.id.enterName);
                            EditText name_tttttt = (EditText) findViewById(R.id.name_input);
                            TextView pw_text = (TextView) findViewById(R.id.password_text);
                            EditText pw_input = (EditText) findViewById(R.id.password_input);

                            Button login_button = (Button) findViewById(R.id.login_button);
                            Button register_button = (Button) findViewById(R.id.new_acc_button);

                            TextView logged_in = (TextView) findViewById(R.id.logged_in_text);

                            phone_text.setVisibility(View.INVISIBLE);
                            phone_input.setVisibility(View.INVISIBLE);
                            name_text.setVisibility(View.INVISIBLE);
                            name_tttttt.setVisibility(View.INVISIBLE);
                            pw_text.setVisibility(View.INVISIBLE);
                            pw_input.setVisibility(View.INVISIBLE);

                            login_button.setVisibility(View.INVISIBLE);
                            register_button.setVisibility(View.INVISIBLE);

                            checkBoxLocation.setVisibility(View.INVISIBLE);

                            logged_in.setVisibility(View.VISIBLE);

                            Toast.makeText(getApplicationContext(), "LOGGED IN!", Toast.LENGTH_SHORT).show();
                        }
                        else
                        {
                            System.out.println("Wrong Password");
                            Toast.makeText(getApplicationContext(), "WRONG PASSWORD", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            }
            else
            {
                for (int i = 0; i < Locations.size(); i++)
                {
                    location l = Locations.get(i);
                    if (name_input.equals(l.name))
                    {
                        isFound = true;
                        if (password_input.equals(l.password))
                        {
                            System.out.println("SUCCESS");
                            this.current_index = i;

                            TextView phone_text = (TextView) findViewById(R.id.EnterPhone);
                            EditText phone_input = (EditText) findViewById(R.id.number_input);
                            TextView name_text = (TextView) findViewById(R.id.enterName);
                            EditText name_tttttt = (EditText) findViewById(R.id.name_input);
                            TextView pw_text = (TextView) findViewById(R.id.password_text);
                            EditText pw_input = (EditText) findViewById(R.id.password_input);

                            Button login_button = (Button) findViewById(R.id.login_button);
                            Button register_button = (Button) findViewById(R.id.new_acc_button);

                            TextView logged_in = (TextView) findViewById(R.id.logged_in_text);

                            phone_text.setVisibility(View.INVISIBLE);
                            phone_input.setVisibility(View.INVISIBLE);
                            name_text.setVisibility(View.INVISIBLE);
                            name_tttttt.setVisibility(View.INVISIBLE);
                            pw_text.setVisibility(View.INVISIBLE);
                            pw_input.setVisibility(View.INVISIBLE);

                            login_button.setVisibility(View.INVISIBLE);
                            register_button.setVisibility(View.INVISIBLE);
                            checkBoxLocation.setVisibility(View.INVISIBLE);

                            logged_in.setVisibility(View.VISIBLE);

                            Toast.makeText(getApplicationContext(), "LOGGED INTO LOCATION!", Toast.LENGTH_SHORT).show();
                        }
                        else
                        {
                            System.out.println("Wrong Password");
                            Toast.makeText(getApplicationContext(), "WRONG PASSWORD", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            }

            if (!isFound)
            {
                System.out.println("ACCOUNT NOT FOUND");
                Toast.makeText(getApplicationContext(), "ACCOUNT NOT FOUND", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void register(View v)
    {
        EditText phone_number_login = (EditText) findViewById(R.id.number_input);
        EditText password_login = (EditText) findViewById(R.id.password_input);
        EditText name_input = (EditText) findViewById(R.id.name_input);

        String number_input = phone_number_login.getText().toString();
        String password_input = password_login.getText().toString();
        String user_name = name_input.getText().toString();

        CheckBox boxLocation = (CheckBox) findViewById(R.id.checkedTextView);
        boolean newLocation = boxLocation.isChecked();

        if (!newLocation)
        {
            Account new_acc = new Account(number_input, password_input, user_name);

            boolean canBeMade = true;

            for (Account a: Accounts)
            {
                if (a.getNumber().equals(number_input))
                {
                    System.out.println("AN ACCOUNT WITH THIS NUMBER ALREADY EXISTS");
                    Toast.makeText(getApplicationContext(), "AN ACCOUNT WITH THIS NUMBER ALREADY EXISTS", Toast.LENGTH_SHORT).show();
                    canBeMade = false;
                }
            }

            if(canBeMade)
            {
                System.out.println("ACCOUNT ADDED. LOGIN WITH IT NOW.");
                Toast.makeText(getApplicationContext(), "ACCOUNT ADDED. LOG IN WITH IT NOW.", Toast.LENGTH_SHORT).show();
                Accounts.add(new_acc);
            }
        }
        else
        {
            location new_location = new location(user_name, password_input);

            boolean canBeMade = true;

            for (location l: Locations)
            {
                if (l.name.equals(new_location.name))
                {
                    Toast.makeText(getApplicationContext(), "AN ACCOUNT WITH THIS NAME ALREADY EXISTS", Toast.LENGTH_SHORT).show();
                    canBeMade = false;
                }
            }

            if(canBeMade)
            {
                Toast.makeText(getApplicationContext(), "LOCATION ACCOUNT ADDED. LOG IN WITH IT NOW.", Toast.LENGTH_SHORT).show();
                Locations.add(new_location);
            }

        }

    }

    public void changeStatus(View v)
    {
        // GREEN: #4CAF50
        // RED: #ff1919

        if (!isLocation)
        {

            Button status = (Button) findViewById(R.id.status);
            if (Accounts.get(current_index).getInfected() == false)
            {
                Accounts.get(current_index).setInfected(true);
                Toast.makeText(getApplicationContext(), "STATUS SET TO INFECTED", Toast.LENGTH_SHORT).show();
                this.date_infected = new Date();
                for (person_met p: Accounts.get(current_index).people_met)
                {
                    Account a = p.person;
                    a.setRisk(true);
                }
            }
            else
            {
                Toast.makeText(getApplicationContext(), "YOU CANNOT CHANGE YOUR STATUS TO UNINFECTED IN LESS THAN 2 WEEKS", Toast.LENGTH_SHORT).show();
            }
        }
        else
        {
            Toast.makeText(getApplicationContext(), "CURRENT ACCOUNT IS A LOCATION. SIGN INTO YOUR INDIVIDUAL ACCOUNT TO CHANGE YOUR STATUS.", Toast.LENGTH_SHORT).show();
        }
    }
}

class person_met
{
        Account person;
        String time;
        Date date;

        public person_met(Account a)
        {
            SimpleDateFormat dtf = new SimpleDateFormat("MM/dd HH:mm");
            this.date = new Date();
            time = dtf.format(date);

            this.person = a;
        }
}

class location
{
    public String password, name;
    public boolean atRisk;
    public ArrayList<person_met> people_here = new ArrayList<person_met>();

    public location(String name, String pw)
    {
        this.password = pw;
        this.name = name;
    }

}

class Account
{
    private String phone, password, name;
    public ArrayList<person_met> people_met;
    private boolean isInfected, atRisk;

    public Account(String phone, String pw, String name)
    {
        this.phone = phone;
        this.password = pw;
        this.name = name;
        this.people_met = new ArrayList<person_met>();
        this.isInfected = false;
    }

    public String getNumber()
    {
        return this.phone;
    }

    public String getPw()
    {
        return this.password;
    }

    public void setPassword(String new_password)
    {
        this.password = new_password;
    }

    public String getName()
    {
        return this.name;
    }

    public boolean getInfected()
    {
        return this.isInfected;
    }

    public void setInfected(boolean infected)
    {
        this.isInfected = infected;
    }

    public boolean getRisk()
    {
        return this.atRisk;
    }

    public void setRisk(boolean risk)
    {
        this.atRisk = risk;
    }
}