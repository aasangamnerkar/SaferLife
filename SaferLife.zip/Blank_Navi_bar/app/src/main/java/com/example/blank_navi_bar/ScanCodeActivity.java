package com.example.blank_navi_bar;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.zxing.Result;

import java.util.ArrayList;
import java.util.Date;

import me.dm7.barcodescanner.zxing.ZXingScannerView;

public class ScanCodeActivity extends AppCompatActivity implements ZXingScannerView.ResultHandler
{

    ZXingScannerView ScannerView;
    int MY_PERMISSIONS_REQUEST_CAMERA=0;
    private static ArrayList<Account> Accounts;
    private static int current_index;
    private static boolean isLocation;
    public ArrayList<location> Locations;

    public void search(String search_input)
    {
        if (search_input.contains("name"))
        {
            isLocation = true;
        }
        else
        {
            isLocation = false;
        }


        if (!isLocation)
        {
            for (int i = 0; i < Accounts.size(); i++)
            {
                String a = Accounts.get(i).getNumber();
                if (a.equals(search_input))
                {
                    Toast.makeText(getApplicationContext(), "ACCOUNT ADDED TO LIST", Toast.LENGTH_SHORT).show();
                    Accounts.get(current_index).people_met.add(new person_met(Accounts.get(i)));
                    Accounts.get(i).people_met.add(new person_met(Accounts.get(current_index)));
                }
            }
        }
        else
        {
            for (int i = 0; i < Locations.size(); i++)
            {
                String a = "name" + Locations.get(i).name;
                if (a.equals(search_input))
                {
                    Toast.makeText(getApplicationContext(), "ACCOUNT ADDED TO LIST", Toast.LENGTH_SHORT).show();

                    int sum = 0;

                    for (person_met p: Locations.get(i).people_here)
                    {
                        Account acc = p.person;
                        if (p.date.compareTo(new Date()) < 1)
                        {
                            Accounts.get(current_index).people_met.add(new person_met(acc));
                            sum++;
                        }
                    }

                    String output = sum + " people added to list through location";

                    Toast.makeText(getApplicationContext(), output, Toast.LENGTH_SHORT).show();

                    Locations.get(i).people_here.add(new person_met(Accounts.get(current_index)));

                }
            }
        }
    }



    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scan_code);

        Toast.makeText(getApplicationContext(), "SCANNER STARTED.", Toast.LENGTH_SHORT).show();

        this.Accounts = MainActivity.getAccounts();
        this.current_index = MainActivity.getIndex();

        this.Locations = MainActivity.getLocations();

        ScannerView = new ZXingScannerView(this);
        setContentView(ScannerView);

    }

    @Override
    public void handleResult(Result result)
    {
        String output = result.getText();
        Toast.makeText(getApplicationContext(), output, Toast.LENGTH_SHORT).show();
        search(output);
        onBackPressed();
    }

    @Override
    protected void onPause()
    {
        super.onPause();

        ScannerView.stopCamera();
    }

    @Override
    protected void onPostResume() {
        super.onPostResume();
        if (ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, MY_PERMISSIONS_REQUEST_CAMERA);
        }
        ScannerView.setResultHandler(this);
        ScannerView.startCamera();
    }

}